# kassa pijltjes

A Pen created on CodePen.

Original URL: [https://codepen.io/Sofie-Schollaert/pen/zxKBwbO](https://codepen.io/Sofie-Schollaert/pen/zxKBwbO).

